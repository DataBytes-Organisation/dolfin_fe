news_data = [
    {
        'id': 1,
        'title': 'First news article',
        'description': 'This is the first news article',
        'content': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
    },
    {
        'id': 2,
        'title': 'Second news article',
        'description': 'This is the second news article',
        'content': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
    },
    {
        'id': 3,
        'title': 'Third news article',
        'description': 'This is the third news article',
        'content': ''
    }
]