home_page_location = "/"
signup_location="/signup"
signin_location="/signin"
dashboard_location="/dashboard"
breakdown_location="/breakdown"
news_location="/news"

TIMEOUT = 60