home_page_location = "/"
signup_location="/signup"
dashboard_location="/dashboard"
breakdown_location="/breakdown"

TIMEOUT = 60